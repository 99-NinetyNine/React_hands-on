import React from "react";
import {Avatar, Heading, VStack, Highlight } from "@chakra-ui/react";

import FullScreenSection from "./FullScreenSection";
import Alert from "./Alert"
const greeting = "Hello, I am Sailesh!";
const bio1 = "A frontend developer";
const bio2 = "specialised in React";

// Implement the UI for the LandingSection component according to the instructions.
// Use a combination of Avatar, Heading and VStack components.
const LandingSection = () => (
  <FullScreenSection
    justifyContent="center"
    alignItems="center"
    isDarkBackground
    backgroundColor="#2A4365"
  >
    <div>
      <Alert />
      
    
        
      <Avatar borderRadius='full'boxSize='150px' name='Drahmov' src='https://i.pravatar.cc/150?img=7' />
    

      <Heading> {greeting} </Heading>
    
      <VStack>
        
        <Heading as='h2' size='xl' lineHeight='tall'>
          {bio1} {bio2}
          
        </Heading>

      </VStack>
    </div>
  </FullScreenSection>
);

export default LandingSection;
